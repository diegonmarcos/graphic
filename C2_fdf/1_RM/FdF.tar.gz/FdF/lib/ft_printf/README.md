# 42Barcelona-Printf
42 Barcelona / Printf with bonus

<h1 align="center">
# 42Barcelona-Printf

</h1>

<p align="center">
	<b><i>42 Barcelona / Printf with bonus</i></b><br>
</p>
<p align="center">
	<img alt="GitHub code size in bytes" src="https://img.shields.io/github/languages/code-size/aitorlopez42/42Barcelona-Printf?color=lightblue" />
	<img alt="Number of lines of code" src="https://img.shields.io/tokei/lines/github/aitorlopez42/42Barcelona-Printf?color=critical" />
	<img alt="Code language count" src="https://img.shields.io/github/languages/count/aitorlopez42/42Barcelona-Printf?color=yellow" />
	<img alt="GitHub top language" src="https://img.shields.io/github/languages/top/aitorlopez42/42Barcelona-Printf?color=blue" />
	<img alt="GitHub last commit" src="https://img.shields.io/github/last-commit/aitorlopez42/42Barcelona-Printf?color=green" />
</p>


---

[![ailopez-'s 42 ft_printf Score](https://badge42.vercel.app/api/v2/cl4nxxx7w020009mdmpbkiyt4/project/2595953)](https://github.com/JaeSeoKim/badge42)
