# libft
42Barcelona / Lift

[![ailopez-'s 42 Libft Score](https://badge42.vercel.app/api/v2/cl4nxxx7w020009mdmpbkiyt4/project/2584752)](https://github.com/JaeSeoKim/badge42)
