# push-swap-clicker
A program to visualize push swap manual moves. Are you still trying to get this special sorting algorithm in your head to work? No more paper, imagination or other stuff needed. Just click, click, click and see if it will work.



Made in Godot 4.1.1 
Download Godot:

Linux:
https://github.com/godotengine/godot/releases/download/4.1.1-stable/Godot_v4.1.1-stable_linux.x86_64.zip

Mac:
https://github.com/godotengine/godot/releases/download/4.1.1-stable/Godot_v4.1.1-stable_macos.universal.zip

Windows:
https://github.com/godotengine/godot/releases/download/4.1.1-stable/Godot_v4.1.1-stable_win64.exe.zip

Just download Godot, clone push-swap-clicker somewhere, import the project into Godot and run it.


[project](https://github.com/stevebalk/push-swap-clicker)



I hope this will help you a little bit. :)

![Screenshot from 2023-10-04 13-18-27](https://github.com/stevebalk/push-swap-clicker/assets/118443457/7eb3b0f1-1a60-40d9-9b9c-a41f8e23349d)

![Screenshot from 2023-10-04 13-18-46](https://github.com/stevebalk/push-swap-clicker/assets/118443457/56b90c49-cc59-4539-841c-698919cca071)
