# _coverpage.md

<div class="cover">
  <div class="cover-main">
    <h1>My Awesome Project</h1> 
    <p>The best documentation ever!</p>
    <a href="readme.md" class="button">Get Started</a>
  </div>
  <div class="cover-logo">
    <img src="https://github.com/diegonmarcos/diegonmarcos/raw/main/img/penguin_ducks.png" /> 
  </div>
</div>

# HELLO WORLD!
|
|
|
V
